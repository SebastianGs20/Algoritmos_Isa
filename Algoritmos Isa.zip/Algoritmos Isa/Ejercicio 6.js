//6.	Modifica el algoritmo anterior, para que muestre las dos opciones de pago
let C1,C2,C3,Valorsuma,MetodoPago;

C1= ('pantalon', 150.000)
C2= ('camisa',75.000)
C3= ('chaqueta',250.000)

Valorsuma = C1+C2+C3
console.log("Señor Fernandez el total de sus compras es: "+ Valorsuma.toFixed(3));
console.log("opciones de pago");
console.log("1. Efectivo");
console.log("2. Tarjeta Credito o Debito");

MetodoPago = prompt("Selecciones una opcion (1/2): ");

if (MetodoPago === '1'){

    let cantidadEfectivo =parseFloat(prompt("Ingresa la cantidad de dinero con la cual va a pagar"));

    if (cantidadEfectivo >= Valorsuma) {
      let cambio = cantidadEfectivo - Valorsuma;
      console.log("Pago en efectivo:");
      console.log("Total a pagar: " + Valorsuma.toFixed(3));
      console.log("Cantidad entregada: " + cantidadEfectivo.toFixed(3));
      console.log("Cambio: " + cambio.toFixed(3));
    } else {
      console.log("La cantidad de no es suficiente para realizar la compra.");
    }

} else if (MetodoPago === '2') {

    let primeros6Digitos = prompt("Ingrese los primeros 6 dígitos de la tarjeta:");
    let ultimos4Digitos = prompt("Ingrese los últimos 4 dígitos de la tarjeta:");
    let cuotas = parseInt(prompt("Ingrese el número de cuotas:"));
    let firma = prompt("Ingrese el nombre del cliente:");
  
    console.log("Pago con tarjeta de crédito:");
    console.log("Primeros 3 dígitos de la Cedula: " + primeros6Digitos);
    console.log("Últimos 4 dígitos de la tarjeta: " + ultimos4Digitos);
    console.log("Número de cuotas: " + cuotas);
    console.log("Firma del cliente: " + firma);
  } else {
    console.log("Opción de pago no valida.");
}
