//Cuantos pares hay
let cont=0;

for (let i = 0; i <= 200; i++) {
    console.log(i);
    if (i%2==0){
        cont++;
    }
}
console.log('numeros pares igual= '+ cont);