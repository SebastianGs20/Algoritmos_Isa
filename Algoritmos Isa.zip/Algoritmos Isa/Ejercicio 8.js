//8.Realiza el algoritmo que muestre los primeros n números de la serie de Fibonacci

let n=prompt('Ingrese el limite de la serie Fibonacci:','');
let ini1=0;
let ini2=1;

for (let i = 0; i <= n; i++) {
    let serie =ini1+ini2;
    console.log(serie);
    ini1=ini2; 
    ini2=serie;
}
