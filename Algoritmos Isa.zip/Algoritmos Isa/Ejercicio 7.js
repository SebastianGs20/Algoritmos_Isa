//7.	Modifica el algoritmo anterior, para que muestre las dos opciones de pago
let C1, C2, C3, ValorSuma, MetodoPago;

C1 = { nombre: 'pantalon', precio: 150000 };
C2 = { nombre: 'camisa', precio: 75000 };
C3 = { nombre: 'chaqueta', precio: 250000 };

ValorSuma = C1.precio + C2.precio + C3.precio;

console.log("Señor Fernandez el total de sus compras es: " + ValorSuma);
console.log("Opciones de pago:");
console.log("1. Efectivo");
console.log("2. Tarjeta Crédito o Débito");

MetodoPago = prompt("Seleccione una opción (1/2): ");

if (MetodoPago === '1') {
    let cantidadEfectivo = parseFloat(prompt("Ingrese la cantidad de dinero con la que va a pagar"));

    if (cantidadEfectivo >= ValorSuma) {
        let cambio = cantidadEfectivo - ValorSuma;

        if (ValorSuma > 300000) {
            let descuento = ValorSuma * 0.15;
            ValorSuma = descuento;
            console.log("Se aplicó un descuento del 15%.");
        }

        console.log("Pago en efectivo:");
        console.log("Total a pagar: " + ValorSuma);
        console.log("Cantidad entregada: " + cantidadEfectivo);
        console.log("Cambio: " + cambio);
    } else {
        console.log("La cantidad no es suficiente para realizar la compra.");
    }
} else if (MetodoPago === '2') {
    let primeros6Digitos = prompt("Ingrese los primeros 6 dígitos de la tarjeta:");
    let ultimos4Digitos = prompt("Ingrese los últimos 4 dígitos de la tarjeta:");
    let cuotas = parseInt(prompt("Ingrese el número de cuotas:"));
    let firma = prompt("Ingrese el nombre del cliente:");

    console.log("Pago con tarjeta de crédito:");
    console.log("Primeros 6 dígitos de la tarjeta: " + primeros6Digitos);
    console.log("Últimos 4 dígitos de la tarjeta: " + ultimos4Digitos);
    console.log("Número de cuotas: " + cuotas);
    console.log("Firma del cliente: " + firma);
} else {
    console.log("Opción de pago no válida.");
}
