//2. 3.	Elabora un algoritmo que muestre los números del 1 al 200

for (let i = 0; i <= 200; i++) {
    console.log(i);
}