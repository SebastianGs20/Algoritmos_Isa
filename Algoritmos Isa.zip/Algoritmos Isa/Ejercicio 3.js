//4.	Modifica el algoritmo anterior para que muestre solo los números pares.
for (let i = 0; i <= 200; i++) {
    if (i%2==0){
        console.log(i);
    }
    
}