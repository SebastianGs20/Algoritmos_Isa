//6.El señor Fernández va a Falabella a comprar 
let C1,C2,C3,Valorsuma

C1= ('pantalon', 150.000)
C2= ('camisa',75.000)
C3= ('chaqueta',250.000)

Valorsuma = C1+C2+C3
console.log("Señor Fernandez el total de sus compras es: "+ Valorsuma.toFixed(3));