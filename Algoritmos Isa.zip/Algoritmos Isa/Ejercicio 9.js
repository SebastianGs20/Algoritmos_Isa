//9.Elabora el algoritmo que diga si un número es primo o no

let numero=prompt('Ingrese un numero','');
let cont=0;
for (let i=1;i<=numero;i++) {
    if (numero%i==0){
        cont++;
    }           
}
if (cont==2){
    console.log ("es primo");
}else {
    console.log( "no es primo");
}