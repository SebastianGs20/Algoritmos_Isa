//1. Elabore un algoritmo que diga si un triangulo es isosceles, equilatero o escaleno
const ladoA=prompt('Ingrese el valor del lado A:',"")
const ladoB=prompt('Ingrese el valor del lado B:', "")
const ladoC=prompt('Ingrese el valor del lado C:', "")

if (ladoA === ladoB && ladoB === ladoC) {
    console.log('El triangulo es Equilatero');
}else if (ladoA === ladoB || ladoA === ladoC || ladoB === ladoC){
    console.log('El triangulo es isosceles');
}else {
    console.log('El triangulo es escaleno');
}


